# 検定対策サイト 公開用

このフォルダの `index.html` をそのまま公開してください。

## Netlifyで公開する方法
1. zipファイルを解凍する
2. NetlifyのDeploy画面へ `kentei_site_public` フォルダをアップロードする
3. 発行されたURLをiPhoneのSafariで開く

## GitHub Pagesで公開する方法
1. 新しいリポジトリを作成する
2. `index.html` をリポジトリ直下へアップロードする
3. Settings → Pages → Deploy from a branch を選択する
4. main / root を選択して保存する

学習記録はSafariのlocalStorageに保存されます。
同じ公開URLを同じSafariで開けば、サイトを閉じても正答率や間違えた問題が残ります。
